from django.db import models
import datetime

# Create your models here.
class Student(models.Model):
    Studentname=models.CharField(max_length=20)
    Fathersname=models.CharField(max_length=20)
    Dob=models.DateField(max_length=8)
    Address=models.TextField(null=True,blank=True)
    City=models.CharField(max_length=10)
    State=models.CharField(max_length=10)
    pin=models.CharField(max_length=6)
    Mobile_no=models.CharField(max_length=10)
    Email=models.EmailField(max_length=30)
    Class=models.CharField(max_length=2)
    Marks=models.CharField(max_length=2)
    Created_date=models.DateTimeField(auto_now_add=True,blank=True,null=True)
    Last_updated_date=models.DateTimeField(auto_now=True,blank=True,null=True)    
    def __str__(self):
          return self.Name






