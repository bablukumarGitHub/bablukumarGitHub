from django import forms
from django.db import models
from .models import Student




class StudentForm(forms.ModelForm):
    
    class Meta:
        model = Student
        fields = '__all__'



    def _init_(self,args,*kwargs):
     super()._init_(*args,**kwargs)
     for field in self.fields.values():
        field.widget.attrs["class"]="form-control"        
        
        



