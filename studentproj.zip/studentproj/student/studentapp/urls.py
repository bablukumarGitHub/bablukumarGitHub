from django.urls import path
from .views import *


urlpatterns = [
    path('add',view_student,name='add'),
    path('show',view_show,name='show'),
    path('edit/<int:id>/',update_student,name='edit'),
    path('delete/<int:id>/',delete_student,name='delete'),

]
