from django.shortcuts import render,redirect

import studentapp
from .models import Student
from django.contrib.auth.forms import UserCreationForm
from studentapp.forms import StudentForm
from .models import *
from .forms import *
from django.http.response import HttpResponse



def view_student(request):
    if request.method=='GET':              
        frm_unbound=StudentForm()
        d1={'student':frm_unbound}
        resp=render(request,'studentapp/add.html',context=d1)
        return resp
    elif request.method=='POST':
        frm_bound=StudentForm()
        if frm_bound.is_valid():
            d1={'student':frm_bound}
            frm_bound.save()
            # return HttpResponse("<h1>Student Added Successfully</h1>")
            return redirect('studentapp/show')

    else:
        frm_bound=StudentForm()
        #if frm_bound.is_valid():
        d1 ={'form':frm_bound}
        resp=render(request,'studentapp/add.html',context=d1)
        return resp
        #return HttpResponse("<h1>Student Added Not Successfully</h1>")



def view_show(request):
    u=Student.objects.all()
    d1={'data':u}
    resp=render(request,'studentapp/show.html',context=d1)
    return resp

def update_student(request,id):
    employee=Student.objects.get(id=id)
    form_unbound=StudentForm(instance=studentapp)
    if request.method=='POST':
        form_unbound=StudentForm(request.POST,instance=studentapp)
        if form_unbound.is_valid():
            form_unbound.save()
            return redirect('/studentapp/show')
    d1={'student':form_unbound}
    resp=render(request,'student/add.html',context=d1)
    return resp

def delete_student(request,id):
    student=Student.objects.get(id=id)
    
    student.delete()
    return render(request,'student/delete.html')    
